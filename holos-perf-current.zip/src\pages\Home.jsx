import React, { useEffect } from 'react';
import { supabase as base44 } from '@/api/supabaseClient';
import { createPageUrl } from '@/utils';

export default function Home() {
  useEffect(() => {
    let isMounted = true;
    
    const checkAuth = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        
        if (!isMounted) return;
        
        if (!isAuth) {
          base44.auth.redirectToLogin();
          return;
        }

        // Si authentifié, charger l'utilisateur et rediriger vers sa page d'accueil
        const userData = await base44.auth.me();
        
        if (!isMounted) return;
        
        // Définir automatiquement le statut "athlete" si pas de statut
        if (!userData.user_status) {
          await base44.auth.updateMe({ 
            user_status: 'athlete',
            role: 'user'
          });
          userData.user_status = 'athlete';
          userData.role = 'user';
        }

        if (!isMounted) return;

        // Rediriger vers la page appropriée selon le statut
        if (userData.user_status === 'admin') {
          window.location.href = createPageUrl('AdminHome');
        } else if (userData.user_status === 'coach' || userData.user_status === 'coach_pro') {
          window.location.href = createPageUrl('CoachHome');
        } else {
          window.location.href = createPageUrl('AthleteHome');
        }
      } catch (error) {
        if (isMounted && error.message !== 'Request aborted') {
          console.error('Error loading user:', error);
          base44.auth.redirectToLogin();
        }
      }
    };
    
    checkAuth();
    
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
      <p className="text-slate-500">Redirection...</p>
    </div>
  );
}